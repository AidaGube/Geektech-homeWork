async function cardFetch() {
    let response = await fetch('https://jsonplaceholder.typicode.com/posts')
    let data = await response.json()
    data = data.splice(0, 1)

    let cardTitle = document.querySelector('.card__tit')
    let key;

    for (key in data) {
        cardTitle.innerHTML += `
        <div class="card__title">
        <h3>${data[key].title}</h3>
         <p> ${data[key].body}</p>
        </div>
        `
    }
}
cardFetch()

// let cardTitle = document.querySelector('.card__tit')
// fetch('https://jsonplaceholder.typicode.com/posts')
// .then(response => response.json())
// .then(item => {
//     cardTitle.innerHTML = `
//          <div class="card__title">
 //       <h3>${item.title}</h3>
  //       <p> ${item.body}</p>
  //      </div>           
//     `
// })
